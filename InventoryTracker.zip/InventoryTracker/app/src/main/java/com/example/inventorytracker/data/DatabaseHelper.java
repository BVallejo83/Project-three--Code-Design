package com.example.inventorytracker.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.inventorytracker.model.InventoryItem;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE = "items";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";
    public static final String COL_QTY = "qty";

    public static final String COL_THRESHOLD = "threshold";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql =
                "CREATE TABLE " + TABLE + " (" +
                        COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_NAME + " TEXT NOT NULL, " +
                        COL_QTY + " INTEGER NOT NULL, " +
                        COL_THRESHOLD + " INTEGER NOT NULL" +
                        ")";
        db.execSQL(sql);

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    db.execSQL("DROP TABLE IF EXISTS " + TABLE);
    onCreate(db);
}

public long insertItem(String name, int qty, int threshold) {
    SQLiteDatabase db = getWritableDatabase();
    ContentValues cv = new ContentValues();
    cv.put(COL_NAME, name);
    cv.put(COL_QTY, qty);
    cv.put(COL_THRESHOLD, threshold);
    return db.insert(TABLE, null, cv);
}

public int updateItem(long id, String name, int qty, int threshold) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, name);
        cv.put(COL_QTY, qty);
        cv.put(COL_THRESHOLD, threshold);
        return db.update(TABLE, cv, COL_ID + "=?", new String[]{String.valueOf(id)});
}

public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE, COL_ID + "=?", new String[]{String.valueOf(id)});
}



public InventoryItem getItemById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE + " WHERE " + COL_ID + "=?", new String[]{String.valueOf(id)});
        InventoryItem item = null;
        if (c.moveToFirst()) {
            item = new InventoryItem(
                    c.getLong(0),
                    c.getString(1),
                    c.getInt(2),
                    c.getInt(3)
            );
        }
        c.close();
        return item;

}
   public List<InventoryItem> getAllItems() {
    List<InventoryItem> list = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE + " ORDER BY " + COL_ID + " DESC", null);

    while (c.moveToNext()) {
        list.add(new InventoryItem(
                c.getLong(0),
                c.getString(1),
                c.getInt(2),
                c.getInt(3)
        ));
    }
    c.close();
    return list;
    }
}