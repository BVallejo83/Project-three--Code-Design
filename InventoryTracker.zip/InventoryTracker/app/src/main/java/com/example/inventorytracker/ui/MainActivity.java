package com.example.inventorytracker.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.inventorytracker.R;
import com.example.inventorytracker.adapter.InventoryTrackerAdapter;
import com.example.inventorytracker.data.DatabaseHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity  {

    private InventoryTrackerAdapter adapter;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycleInventory);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new InventoryTrackerAdapter();
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(item -> {
            Intent i = new Intent(MainActivity.this, AddEditItemActivity.class);
            i.putExtra("item_ID", item.getId());
            startActivity(i);
        });

        FloatingActionButton fabAdd = findViewById(R.id.fabAddItem);
        fabAdd.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AddEditItemActivity.class));
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        adapter.setItems(db.getAllItems());
    }
}

