package com.example.inventorytracker.model;

public class InventoryItem {
    private long id;
    private String name;
    private int qty;
    private int threshold;

    // Constructor
    public InventoryItem(long id, String name, int qty, int threshold) {
        this.id = id;
        this.name = name;
        this.qty = qty;
        this.threshold = threshold;
    }

    // You might want a constructor to easily create new items
    public InventoryItem(String name, int qty, int threshold) {
        this.name = name;
        this.qty = qty;
        this.threshold = threshold;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQty() {
        return qty;
    }

    public int getThreshold() {
        return threshold;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public void setThreshold(int threshold) {
        this.threshold = threshold;
    }
}
