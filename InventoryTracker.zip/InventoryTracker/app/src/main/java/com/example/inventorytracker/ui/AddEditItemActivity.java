package com.example.inventorytracker.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventorytracker.R;
import com.example.inventorytracker.data.DatabaseHelper;
import com.example.inventorytracker.model.InventoryItem;

public class AddEditItemActivity  extends AppCompatActivity {

    private EditText etName, etQty, etThreshold;
    private DatabaseHelper db;
    private long itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_item);

        etName = findViewById(R.id.etItemName);
        etQty = findViewById(R.id.etItemQty);
        etThreshold = findViewById(R.id.etItemThreshold);
        Button btnSave = findViewById(R.id.btnSaveItem);
        Button btnDelete = findViewById(R.id.btnDeleteItem);

        itemId = getIntent().getLongExtra("item_id", -1);

        if (itemId != -1) {
            InventoryItem item = db.getItemById(itemId);
            if (item != null) {
                etName.setText(item.getName());
                etQty.setText(String.valueOf(item.getQty()));
                etThreshold.setText(String.valueOf(item.getThreshold()));
            }
            btnDelete.setEnabled(true);
        } else {
            btnDelete.setEnabled(false);
        }

        btnSave.setOnClickListener(v -> saveItem());
        btnDelete.setOnClickListener(v -> deleteItem());
    }

    private void saveItem() {
            String name = etName.getText().toString().trim();
            String qtyStr = etQty.getText().toString().trim();
            String thrStr = etThreshold.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty() || thrStr.isEmpty()) {
                Toast.makeText(this, "Fill out all field.", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty, threshold;
            try {
                qty = Integer.parseInt(qtyStr);
                threshold = Integer.parseInt(thrStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (itemId == -1) {
                db.insertItem(name, qty, threshold);
                Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();
            } else {
                db.updateItem(itemId, name, qty, threshold);
                Toast.makeText(this, "Item updated.", Toast.LENGTH_SHORT).show();
            }
            finish();
        }

    private void deleteItem() {
        if (itemId == -1) {
            db.deleteItem(itemId);
            Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}