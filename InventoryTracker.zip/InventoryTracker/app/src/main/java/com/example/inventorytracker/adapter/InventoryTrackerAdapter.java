package com.example.inventorytracker.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventorytracker.R;
import com.example.inventorytracker.model.InventoryItem;

import java.util.ArrayList;
import java.util.List;

public class InventoryTrackerAdapter
    extends RecyclerView.Adapter<InventoryTrackerAdapter.VH> {

    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    private final List<InventoryItem> items = new ArrayList<>();
    private OnItemClickListener listener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setItems(List<InventoryItem> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        InventoryItem item = items.get(position);

        holder.txtName.setText(item.getName());
        holder.txtQty.setText("Qty: " + item.getQty());
        holder.txtThreshold.setText("Threshold: " + item.getThreshold());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(item);
        });
    }

        @Override
        public int getItemCount () {
            return items.size();
        }
        static class VH extends RecyclerView.ViewHolder {
            TextView txtName, txtQty, txtThreshold;

            VH(@NonNull View itemView) {
                super(itemView);
                txtName = itemView.findViewById(R.id.txtName);
                txtQty = itemView.findViewById(R.id.txtQty);
                txtThreshold = itemView.findViewById(R.id.txtThreshold);
            }
        }
    }