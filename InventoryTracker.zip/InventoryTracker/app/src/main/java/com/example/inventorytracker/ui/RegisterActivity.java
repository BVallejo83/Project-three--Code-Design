package com.example.inventorytracker.ui;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventorytracker.R;
import com.example.inventorytracker.data.DatabaseHelper;

public class RegisterActivity extends AppCompatActivity {

    private EditText etRegUsername;
    private EditText etRegPassword;
    private Button btnCreateAccount;

    private DatabaseHelper databaseHelper;

    private static final String USERS_TABLE = "users";
    private static final String COL_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etRegUsername = findViewById(R.id.etRegUser);
        etRegPassword = findViewById(R.id.etRegPass);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);


        databaseHelper = new DatabaseHelper(this);
        btnCreateAccount.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {

        String username = etRegUsername.getText().toString().trim();
        String password = etRegPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = databaseHelper.getWritableDatabase();


        Cursor cursor = db.query(
                USERS_TABLE,
                new String[]{COL_ID},
                COL_USERNAME + "=?",
                new String[]{username},
                null, null, null
        );

        if (cursor != null && cursor.moveToFirst()) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            cursor.close();
            return;
        }

        if (cursor != null) {
            cursor.close();
        }


        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(USERS_TABLE, null, values);

        if (result != -1) {
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Account creation failed", Toast.LENGTH_SHORT).show();
        }
    }
        }


